# मनिषा रानी Android Project (प्रारंभिक संस्करण)

यह Android Studio/Gradle प्रोजेक्ट है, तैयार APK नहीं। इसमें हिंदी में एक शुरुआती ऐप स्क्रीन और माइक्रोफोन अनुमति जाँचने का बटन है। असली speech-to-text, text-to-speech, wake-word, speaker verification, Magahi voice और accessibility automation अभी शामिल नहीं हैं।

## फोन से ऑनलाइन APK बनाने का रास्ता
1. इस ZIP को डाउनलोड और extract करें।
2. GitHub पर नया repository बनाकर इस ZIP के अंदर की फाइलें अपलोड करें (ZIP को सीधे repository में डालना पर्याप्त नहीं है; पहले extract करना होगा)।
3. Repository में **Actions** टैब खोलें और **Build Manisha Rani APK** workflow चुनकर **Run workflow** दबाएँ।
4. Build सफल होने पर run के नीचे **Artifacts** में `manisha-rani-debug-apk` डाउनलोड करें। ZIP खोलकर `app-debug.apk` निकालें और अपने फोन पर install करें।

सावधानी: केवल अपने बनाए/विश्वसनीय source से APK install करें। यह debug APK होगी, Play Store release नहीं। इस वातावरण में Android build चलाकर APK की पुष्टि नहीं की गई है।

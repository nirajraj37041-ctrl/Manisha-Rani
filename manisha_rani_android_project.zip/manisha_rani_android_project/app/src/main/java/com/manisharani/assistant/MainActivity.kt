package com.manisharani.assistant

import android.Manifest
import android.app.Activity
import android.content.pm.PackageManager
import android.os.Bundle
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.view.Gravity
import android.view.ViewGroup
import android.graphics.Typeface

class MainActivity : Activity() {
    private lateinit var status: TextView
    private val micRequestCode = 101

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(28, 28, 28, 28)
        }
        val title = TextView(this).apply {
            text = "मनिषा रानी"
            textSize = 30f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
        }
        val subtitle = TextView(this).apply {
            text = "तुम्हारी हिंदी वॉइस असिस्टेंट"
            textSize = 18f
            gravity = Gravity.CENTER
            setPadding(0, 12, 0, 24)
        }
        status = TextView(this).apply {
            text = "प्रोजेक्ट शुरुआती संस्करण है। आवाज़ पहचान और wake-word अभी जोड़े नहीं गए हैं।"
            textSize = 15f
            gravity = Gravity.CENTER
            setPadding(0, 0, 0, 24)
        }
        val micButton = Button(this).apply {
            text = "माइक्रोफोन अनुमति जाँचें"
            setOnClickListener { checkMicrophonePermission() }
        }
        root.addView(title, ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        root.addView(subtitle, ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        root.addView(status, ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        root.addView(micButton, ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        setContentView(root)
    }

    private fun checkMicrophonePermission() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
            status.text = "माइक्रोफोन अनुमति मिल चुकी है। आवाज़ पहचान इंजन अभी इस संस्करण में शामिल नहीं है।"
        } else {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), micRequestCode)
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == micRequestCode) {
            status.text = if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                "माइक्रोफोन अनुमति मिल गई। आवाज़ पहचान इंजन अभी जोड़ना बाकी है।"
            } else {
                "माइक्रोफोन अनुमति नहीं मिली। चाहो तो Android Settings में अनुमति दे सकते हो।"
            }
        }
    }
}
